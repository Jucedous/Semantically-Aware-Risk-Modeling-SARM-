using System.Collections.Generic;
using UnityEngine;

public class SafetyObject : MonoBehaviour
{
    public string objectName;      // stable unique name
    public string kind;            // "liquid", "electronic", "sharp", etc (optional)
    public List<string> tags = new();

    public float radiusOverride = -1f;

    public float GetRadiusMeters()
    {
        if (radiusOverride > 0f) return radiusOverride;

        var col = GetComponentInChildren<Collider>();
        if (col != null)
            return col.bounds.extents.magnitude; // conservative sphere

        return 0.05f;
    }
}
