using System.Collections.Generic;

[System.Serializable]
public class SceneObjectDto {
    public string name;
    public string kind;
    public List<string> tags;
    public float[] xyz;
    public float r;
}

[System.Serializable]
public class CompileRequestDto {
    public string user_id;
    public List<SceneObjectDto> objects;
}

[System.Serializable]
public class RuleDto {
    public string A;
    public string B;
    public float clearance;
    public float weight;
}

// Matches server debug.metadata["A|B"]
[System.Serializable]
public class DebugMetadataEntryDto {
    public string status;          // "llm_only", "rule_confirmed", etc.
    public float confidence;       // 0..1
    public string label;           // "dangerous" / "not_dangerous" / null
    public List<string[]> sources; // list of 2-string arrays (concept pairs)
}

[System.Serializable]
public class CompileDebugDto {
    public Dictionary<string, DebugMetadataEntryDto> metadata;
    public List<object> conflicts;
}

[System.Serializable]
public class CompileResponseDto {
    public string scene_signature;
    public Dictionary<string, string> kinds_by_name;
    public Dictionary<string, float> @params;
    public List<RuleDto> rules;
    public CompileDebugDto debug;  // <-- was object, now typed
}
