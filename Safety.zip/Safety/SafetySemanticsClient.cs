using System.Collections;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;

public class SafetySemanticsClient : MonoBehaviour
{
    public string serverBaseUrl = "http://127.0.0.1:8000";
    public string userId = "local_user";

    [Header("Debug")]
    public bool verboseLogRules = true;

    public CompileResponseDto compiledModel;

    static string CanonKey(string a, string b)
    {
        // Server stores metadata keys in canonical order: "a|b" where a <= b
        return string.CompareOrdinal(a, b) <= 0 ? $"{a}|{b}" : $"{b}|{a}";
    }

    string KindOf(string name)
    {
        if (compiledModel?.kinds_by_name != null &&
            compiledModel.kinds_by_name.TryGetValue(name, out var k) &&
            !string.IsNullOrWhiteSpace(k))
            return k;
        return "object";
    }

    DebugMetadataEntryDto MetaFor(string a, string b)
    {
        var md = compiledModel?.debug?.metadata;
        if (md == null) return null;
        md.TryGetValue(CanonKey(a, b), out var entry);
        return entry;
    }

    public IEnumerator HealthCheck()
    {
        var url = $"{serverBaseUrl}/health";
        using var uwr = UnityWebRequest.Get(url);
        yield return uwr.SendWebRequest();

        if (uwr.result != UnityWebRequest.Result.Success)
            Debug.LogError($"Health failed: {uwr.responseCode} {uwr.error}");
        else
            Debug.Log($"Health OK: {uwr.downloadHandler.text}");
    }

    public IEnumerator CompileNow(List<SafetyObject> sceneObjects)
    {
        // Ensure deterministic request ordering: Unity's FindObjectsOfType order can vary across runs
        // which can change LLM results if the server uses pair ordering in prompts.
        sceneObjects.Sort((a, b) =>
        {
            string an = string.IsNullOrWhiteSpace(a.objectName) ? a.gameObject.name : a.objectName;
            string bn = string.IsNullOrWhiteSpace(b.objectName) ? b.gameObject.name : b.objectName;
            return string.CompareOrdinal(an, bn);
        });

        var req = new CompileRequestDto {
            user_id = userId,
            objects = new List<SceneObjectDto>()
        };

        foreach (var so in sceneObjects)
        {
            string n = string.IsNullOrWhiteSpace(so.objectName) ? so.gameObject.name : so.objectName;
            Vector3 p = so.transform.position;

            req.objects.Add(new SceneObjectDto {
                name = n,
                kind = so.kind ?? "",
                tags = so.tags ?? new List<string>(),
                xyz = new float[] { p.x, p.z, p.y },
                r = so.GetRadiusMeters()
            });
        }

        string json = JsonConvert.SerializeObject(req);
        var url = $"{serverBaseUrl}/v1/compile";

        using var uwr = new UnityWebRequest(url, "POST");
        uwr.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(json));
        uwr.downloadHandler = new DownloadHandlerBuffer();
        uwr.SetRequestHeader("Content-Type", "application/json");

        yield return uwr.SendWebRequest();

        if (uwr.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError($"Compile failed: {uwr.responseCode} {uwr.error}\n{uwr.downloadHandler.text}");
            yield break;
        }
        // Debug.Log("RAW /v1/compile JSON:\n" + uwr.downloadHandler.text);
        compiledModel = JsonConvert.DeserializeObject<CompileResponseDto>(uwr.downloadHandler.text);

        Debug.Log($"Compiled semantic hazards: {compiledModel.rules?.Count ?? 0}, scene_sig={compiledModel.scene_signature}");

        if (!verboseLogRules || compiledModel.rules == null) yield break;

        for (int i = 0; i < compiledModel.rules.Count; i++)
        {
            var r = compiledModel.rules[i];
            var ka = KindOf(r.A);
            var kb = KindOf(r.B);

            var meta = MetaFor(r.A, r.B);
            string metaStr = meta != null
                ? $" | status={meta.status} conf={meta.confidence:0.00} label={meta.label}"
                : "";

            Debug.Log($"HAZARD[{i}] {r.A}({ka}) ↔ {r.B}({kb}) | clearance={r.clearance:0.00}m weight={r.weight:0.00}{metaStr}");
        }
    }
}
