using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SafetyManager : MonoBehaviour
{
    public SafetySemanticsClient client;

    [Header("Export")]
    [Tooltip("Write a JSON snapshot (objects + all pairs + semantic hazards) after /v1/compile returns.")]
    public bool exportSnapshotAfterCompile = true;

    [Tooltip("Write a JSON snapshot when play mode ends / app quits (best for capturing final positions).")]
    public bool exportSnapshotOnQuit = true;

    [Tooltip("Press this key during play mode to write a snapshot immediately.")]
    public bool exportSnapshotOnKeypress = false;
    public KeyCode exportKey = KeyCode.F9;

    [Tooltip("Folder name under the export root. If empty, uses 'SafetyExports'.")]
    public string exportFolderName = "SafetyExports";

    [Tooltip("If > 0, caps exported pair count to avoid huge files. 0 = no limit.")]
    public int maxPairsToExport = 0;

    public bool prettyPrintJson = true;

    [Header("HUD")]
    public bool showHUD = true;
    [Range(1, 10)] public int hudTopHazards = 3;

    [Header("Live values")]
    public float currentSafetyScore;
    public float currentCompositeRisk;

    List<SafetyObject> objs = new();

    bool _hasCompiled;
    bool _exportedOnQuit;

    // Cached HUD display
    readonly List<SafetyRuntimeScoring.RuleRuntimeInfo> _top = new();
    int _compiledHazardCount;
    string _sceneSigShort = "";

    IEnumerator Start()
    {
        // Wait a moment in case IndoorSceneGenerator spawns objects at Start()
        yield return null;
        yield return null;

        RefreshObjects();

        // First confirm connectivity:
        yield return client.HealthCheck();

        // Compile semantics once:
        yield return client.CompileNow(objs);

        _hasCompiled = client != null && client.compiledModel != null;

        if (exportSnapshotAfterCompile && _hasCompiled)
            ExportSnapshotToFile("compiled");
    }

    public void RefreshObjects()
    {
        objs = FindObjectsOfType<SafetyObject>().ToList();
        Debug.Log($"Safety objects found: {objs.Count}");
    }

    public void Recompile()
    {
        StopAllCoroutines();
        StartCoroutine(RecompileRoutine());
    }

    IEnumerator RecompileRoutine()
    {
        RefreshObjects();
        yield return client.CompileNow(objs);

        _hasCompiled = client != null && client.compiledModel != null;

        if (exportSnapshotAfterCompile && _hasCompiled)
            ExportSnapshotToFile("recompiled");
    }

    static string CanonKey(string a, string b)
    {
        return string.CompareOrdinal(a, b) <= 0 ? $"{a}|{b}" : $"{b}|{a}";
    }

    string KindOf(string name)
    {
        if (client?.compiledModel?.kinds_by_name != null &&
            client.compiledModel.kinds_by_name.TryGetValue(name, out var k) &&
            !string.IsNullOrWhiteSpace(k))
            return k;

        return "object";
    }

    DebugMetadataEntryDto MetaFor(string a, string b)
    {
        var md = client?.compiledModel?.debug?.metadata;
        if (md == null) return null;
        md.TryGetValue(CanonKey(a, b), out var entry);
        return entry;
    }

    string DescribeObject(string name)
    {
        // Prefer server-inferred kind (semantic)
        var kind = KindOf(name);

        // If kind is generic, show tags from Unity component as a fallback
        if (kind == "object")
        {
            var so = objs.FirstOrDefault(o =>
            {
                string n = string.IsNullOrWhiteSpace(o.objectName) ? o.gameObject.name : o.objectName;
                return n == name;
            });

            if (so != null && so.tags != null && so.tags.Count > 0)
                return $"{name} [{string.Join(",", so.tags)}]";
        }

        return $"{name} ({kind})";
    }

    void Update()
    {
        if (client?.compiledModel?.rules == null) return;

        if (exportSnapshotOnKeypress && Input.GetKeyDown(exportKey) && _hasCompiled)
            ExportSnapshotToFile("manual");

        float alphaGain = (client.compiledModel.@params != null && client.compiledModel.@params.ContainsKey("alpha_gain"))
            ? client.compiledModel.@params["alpha_gain"] : 5f;

        float scaleRes = (client.compiledModel.@params != null && client.compiledModel.@params.ContainsKey("scale_res"))
            ? client.compiledModel.@params["scale_res"] : 0.05f;

        // Build runtime state (positions + radii)
        var byName = new Dictionary<string, (Vector3 pos, float r)>();
        foreach (var so in objs)
        {
            string n = string.IsNullOrWhiteSpace(so.objectName) ? so.gameObject.name : so.objectName;
            byName[n] = (so.transform.position, so.GetRadiusMeters());
        }

        // Evaluate score + per-rule risks
        var eval = SafetyRuntimeScoring.Evaluate(byName, client.compiledModel.rules, alphaGain, scaleRes);
        currentSafetyScore = eval.safety0To5;
        currentCompositeRisk = eval.compositeRisk0To1;

        // Prepare HUD "top hazards"
        _compiledHazardCount = client.compiledModel.rules.Count;
        var sig = client.compiledModel.scene_signature ?? "";
        _sceneSigShort = sig.Length >= 8 ? sig.Substring(0, 8) : sig;

        _top.Clear();
        if (eval.perRule != null && eval.perRule.Count > 0)
        {
            eval.perRule.Sort((x, y) => y.weightedRisk.CompareTo(x.weightedRisk));
            int take = Mathf.Min(hudTopHazards, eval.perRule.Count);
            for (int i = 0; i < take; i++) _top.Add(eval.perRule[i]);
        }
    }

    void OnApplicationQuit()
    {
        if (!exportSnapshotOnQuit) return;
        if (!_hasCompiled) return;
        if (_exportedOnQuit) return;

        _exportedOnQuit = true;
        ExportSnapshotToFile("quit");
    }

    // In the Unity Editor, stopping play mode does not always behave like a full application quit.
    // OnDisable is a reliable hook to capture a final snapshot.
    void OnDisable()
    {
        if (!exportSnapshotOnQuit) return;
        if (!_hasCompiled) return;
        if (_exportedOnQuit) return;

        _exportedOnQuit = true;
        ExportSnapshotToFile("disable");
    }

    [Serializable]
    public class SafetyRunObjectExportDto
    {
        public string name;
        public int instance_id;
        public string component_kind;
        public string semantic_kind;
        public List<string> tags;
        public float[] unity_xyz;
        public float[] server_xyz;
        public float r;
    }

    [Serializable]
    public class SafetyRunPairExportDto
    {
        public string a;
        public string b;
        public int a_instance_id;
        public int b_instance_id;
        public float distance_m;
        public bool is_semantic_hazard;
    }

    [Serializable]
    public class SafetyRunHazardPairExportDto
    {
        public string A;
        public string B;
        public string kindA;
        public string kindB;
        public float clearance;
        public float weight;

        // Runtime scoring at time of export
        public float distance_m;
        public float residual_m;
        public float risk0To1;
        public float weightedRisk;

        // Server debug metadata (may be null)
        public DebugMetadataEntryDto metadata;
    }

    [Serializable]
    public class SafetyRunSnapshotExportDto
    {
        public string timestamp_utc;
        public string unity_scene;
        public string scene_signature;
        public float safety0To5;
        public float compositeRisk0To1;

        public List<string> duplicate_names;
        public List<SafetyRunObjectExportDto> objects;
        public List<SafetyRunPairExportDto> all_pairs;
        public List<SafetyRunHazardPairExportDto> semantic_hazards;
    }

    string ResolveExportRoot()
    {
#if UNITY_EDITOR
        // More convenient in Editor: put logs in the project root
        var projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        return projectRoot;
#else
        return Application.persistentDataPath;
#endif
    }

    string ResolveExportDirectory()
    {
        var root = ResolveExportRoot();
        var folder = string.IsNullOrWhiteSpace(exportFolderName) ? "SafetyExports" : exportFolderName.Trim();
        return Path.Combine(root, folder);
    }

    void ExportSnapshotToFile(string reason)
    {
        try
        {
            RefreshObjects();

            var dir = ResolveExportDirectory();
            Directory.CreateDirectory(dir);

            var scene = SceneManager.GetActiveScene().name;
            var sig = client?.compiledModel?.scene_signature ?? "";
            var sigShort = sig.Length >= 8 ? sig.Substring(0, 8) : sig;
            var ts = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");

            var file = $"safety_{scene}_{sigShort}_{reason}_{ts}.json";
            var path = Path.Combine(dir, file);

            var snapshot = BuildSnapshot();

            var formatting = prettyPrintJson ? Formatting.Indented : Formatting.None;
            var json = JsonConvert.SerializeObject(snapshot, formatting);
            File.WriteAllText(path, json);

            Debug.Log($"[Safety] Exported snapshot to: {path}");
        }
        catch (Exception ex)
        {
            Debug.LogError($"[Safety] ExportSnapshotToFile failed: {ex}");
        }
    }

    SafetyRunSnapshotExportDto BuildSnapshot()
    {
        var snapshot = new SafetyRunSnapshotExportDto
        {
            timestamp_utc = DateTime.UtcNow.ToString("o"),
            unity_scene = SceneManager.GetActiveScene().name,
            scene_signature = client?.compiledModel?.scene_signature ?? "",
            safety0To5 = currentSafetyScore,
            compositeRisk0To1 = currentCompositeRisk,
            duplicate_names = new List<string>(),
            objects = new List<SafetyRunObjectExportDto>(),
            all_pairs = new List<SafetyRunPairExportDto>(),
            semantic_hazards = new List<SafetyRunHazardPairExportDto>(),
        };

        // Build object exports + detect duplicates
        var nameCounts = new Dictionary<string, int>();
        var instances = new List<(string name, int id, Vector3 pos, float r)>();

        foreach (var so in objs)
        {
            if (so == null) continue;
            string n = string.IsNullOrWhiteSpace(so.objectName) ? so.gameObject.name : so.objectName;
            int id = so.gameObject.GetInstanceID();
            Vector3 p = so.transform.position;
            float r = so.GetRadiusMeters();

            if (!nameCounts.ContainsKey(n)) nameCounts[n] = 0;
            nameCounts[n]++;

            var semanticKind = KindOf(n);
            var componentKind = so.kind ?? "";

            snapshot.objects.Add(new SafetyRunObjectExportDto
            {
                name = n,
                instance_id = id,
                component_kind = componentKind,
                semantic_kind = semanticKind,
                tags = so.tags ?? new List<string>(),
                unity_xyz = new float[] { p.x, p.y, p.z },
                // Matches the ordering used in CompileNow
                server_xyz = new float[] { p.x, p.z, p.y },
                r = r,
            });

            instances.Add((n, id, p, r));
        }

        foreach (var kv in nameCounts)
            if (kv.Value > 1)
                snapshot.duplicate_names.Add(kv.Key);

        // Hazard key lookup
        var hazardKeys = new HashSet<string>();
        if (client?.compiledModel?.rules != null)
            foreach (var rule in client.compiledModel.rules)
                if (rule != null)
                    hazardKeys.Add(CanonKey(rule.A, rule.B));

        // Export all unordered instance pairs
        int exportedPairs = 0;
        for (int i = 0; i < instances.Count; i++)
        {
            for (int j = i + 1; j < instances.Count; j++)
            {
                if (maxPairsToExport > 0 && exportedPairs >= maxPairsToExport)
                    break;

                var a = instances[i];
                var b = instances[j];
                float d = Vector3.Distance(a.pos, b.pos);

                snapshot.all_pairs.Add(new SafetyRunPairExportDto
                {
                    a = a.name,
                    b = b.name,
                    a_instance_id = a.id,
                    b_instance_id = b.id,
                    distance_m = d,
                    is_semantic_hazard = hazardKeys.Contains(CanonKey(a.name, b.name)),
                });
                exportedPairs++;
            }

            if (maxPairsToExport > 0 && exportedPairs >= maxPairsToExport)
                break;
        }

        // Build runtime state (positions + radii), keyed by name (same behavior as scoring)
        var byName = new Dictionary<string, (Vector3 pos, float r)>();
        foreach (var so in objs)
        {
            if (so == null) continue;
            string n = string.IsNullOrWhiteSpace(so.objectName) ? so.gameObject.name : so.objectName;
            byName[n] = (so.transform.position, so.GetRadiusMeters());
        }

        // Evaluate hazards at time of export
        if (client?.compiledModel?.rules != null)
        {
            float alphaGain = (client.compiledModel.@params != null && client.compiledModel.@params.ContainsKey("alpha_gain"))
                ? client.compiledModel.@params["alpha_gain"]
                : 5f;

            float scaleRes = (client.compiledModel.@params != null && client.compiledModel.@params.ContainsKey("scale_res"))
                ? client.compiledModel.@params["scale_res"]
                : 0.05f;

            var eval = SafetyRuntimeScoring.Evaluate(byName, client.compiledModel.rules, alphaGain, scaleRes);
            snapshot.safety0To5 = eval.safety0To5;
            snapshot.compositeRisk0To1 = eval.compositeRisk0To1;

            if (eval.perRule != null)
            {
                foreach (var info in eval.perRule)
                {
                    var r = info.rule;
                    if (r == null) continue;

                    snapshot.semantic_hazards.Add(new SafetyRunHazardPairExportDto
                    {
                        A = r.A,
                        B = r.B,
                        kindA = KindOf(r.A),
                        kindB = KindOf(r.B),
                        clearance = r.clearance,
                        weight = r.weight,

                        distance_m = info.distance,
                        residual_m = info.residual,
                        risk0To1 = info.risk0To1,
                        weightedRisk = info.weightedRisk,

                        metadata = MetaFor(r.A, r.B),
                    });
                }
            }
        }

        return snapshot;
    }

    void OnGUI()
    {
        if (!showHUD) return;

        float width = 760f;
        float height = 115f + 22f * Mathf.Max(hudTopHazards, 1);

        var box = new Rect(20, 20, width, height);
        GUI.Box(box, "");

        GUILayout.BeginArea(new Rect(30, 30, width - 20, height - 20));

        if (client?.compiledModel?.rules == null)
        {
            GUILayout.Label("Safety: waiting for /v1/compile ...");
            GUILayout.EndArea();
            return;
        }

        GUILayout.Label($"Safety Score: {currentSafetyScore:0.00} / 5.00");
        GUILayout.Label($"Composite Risk: {currentCompositeRisk:0.00}");
        GUILayout.Label($"Semantic hazards (compiled): {_compiledHazardCount}   scene_sig={_sceneSigShort}…");

        if (_top.Count == 0)
        {
            GUILayout.Label("No active hazards scored (missing objects for rules or no rules returned).");
            GUILayout.EndArea();
            return;
        }

        for (int i = 0; i < _top.Count; i++)
        {
            var info = _top[i];
            var r = info.rule;

            var meta = MetaFor(r.A, r.B);
            string metaStr = "";
            if (meta != null)
            {
                // label may be null/empty, keep it short
                var label = string.IsNullOrWhiteSpace(meta.label) ? "" : $" {meta.label}";
                metaStr = $" | {meta.status}{label} conf={meta.confidence:0.00}";
            }

            string resStr = info.residual.ToString("+0.00;-0.00;0.00");
            GUILayout.Label(
                $"{i + 1}) {DescribeObject(r.A)} ↔ {DescribeObject(r.B)}" +
                $" | risk={info.risk0To1:0.00} res={resStr}m clr={r.clearance:0.00}m w={r.weight:0.00}{metaStr}"
            );
        }

        GUILayout.EndArea();
    }
}
