using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Visualizes the semantic hazard pairs returned by SafetySemanticsClient (/v1/compile)
/// by drawing a LineRenderer between each pair.
///
/// - Lines are GREEN when safe (distance >= rA + rB + clearance).
/// - When too close (residual < 0), the line transitions toward RED.
/// - Optional switch: show all lines vs. only violating ("red") lines.
/// </summary>
[DefaultExecutionOrder(50)]
public class SafetyLineVisualizer : MonoBehaviour
{
    [Header("References")]
    [Tooltip("Optional. If set, the visualizer will use this manager's client and object list.")]
    public SafetyManager manager;

    [Tooltip("Optional. If not set, the visualizer will try to use manager.client, or FindObjectOfType<SafetySemanticsClient>().")]
    public SafetySemanticsClient client;

    [Header("Visibility")]
    public bool showLines = true;

    [Tooltip("If true, only show lines for pairs that are currently violating clearance (residual < 0).")]
    public bool onlyShowViolatingLines = false;

    [Tooltip("Optional runtime toggle for onlyShowViolatingLines.")]
    public bool enableKeyboardToggle = true;
    public KeyCode toggleOnlyViolationsKey = KeyCode.F8;

    [Header("Style")]
    [Tooltip("Line width in world units (meters).")]
    public float lineWidth = 0.02f;

    [Tooltip("How deep (in meters) the clearance violation must be for the line to become fully RED.\nExample: 0.25 means 25cm inside the clearance boundary => red.")]
    public float violationSaturationMeters = 0.25f;

    public Color safeColor = Color.green;
    public Color dangerColor = Color.red;

    [Tooltip("Optional material. If null, a simple runtime material is created (Sprites/Default).")]
    public Material lineMaterial;

    [Header("Maintenance")]
    [Tooltip("How often (seconds) to refresh object references / rebuild lines if something changes.")]
    public float refreshInterval = 0.25f;

    [Tooltip("If true, the visualizer will rebuild its line list when /v1/compile results change.")]
    public bool rebuildWhenCompiledModelChanges = true;

    class LineLink
    {
        public RuleDto rule;
        public LineRenderer lr;
        public SafetyObject a;
        public SafetyObject b;
        public string aName;
        public string bName;
    }

    readonly List<LineLink> _links = new();
    readonly Dictionary<string, SafetyObject> _byName = new();

    CompileResponseDto _lastModelRef;
    int _lastRuleCount;
    float _nextRefreshTime;
    Material _runtimeMat;

    void Awake()
    {
        if (manager == null)
            manager = FindObjectOfType<SafetyManager>();

        if (client == null)
            client = manager != null ? manager.client : FindObjectOfType<SafetySemanticsClient>();
    }

    void OnEnable()
    {
        _nextRefreshTime = 0f;
    }

    void OnDisable()
    {
        // Don't destroy child GameObjects in edit-time hot reloads; but do disable renderers.
        SetAllEnabled(false);
    }

    void Update()
    {
        if (enableKeyboardToggle && Input.GetKeyDown(toggleOnlyViolationsKey))
            onlyShowViolatingLines = !onlyShowViolatingLines;

        if (Time.unscaledTime >= _nextRefreshTime)
        {
            _nextRefreshTime = Time.unscaledTime + Mathf.Max(0.05f, refreshInterval);
            RefreshAndMaybeRebuild();
        }

        UpdateLines();
    }

    void RefreshAndMaybeRebuild()
    {
        if (client == null)
            client = manager != null ? manager.client : FindObjectOfType<SafetySemanticsClient>();

        var model = client != null ? client.compiledModel : null;
        var rules = model != null ? model.rules : null;
        int ruleCount = rules != null ? rules.Count : 0;

        bool modelChanged = (model != _lastModelRef) || (ruleCount != _lastRuleCount);
        if (rebuildWhenCompiledModelChanges && modelChanged)
        {
            _lastModelRef = model;
            _lastRuleCount = ruleCount;
            RebuildLines();
        }

        // Always refresh object map (handles runtime-spawned objects / renames)
        RefreshObjectMap();
    }

    void RefreshObjectMap()
    {
        _byName.Clear();

        var all = FindObjectsOfType<SafetyObject>();
        foreach (var so in all)
        {
            if (so == null) continue;
            string n = string.IsNullOrWhiteSpace(so.objectName) ? so.gameObject.name : so.objectName;
            if (string.IsNullOrWhiteSpace(n)) continue;

            // If duplicates exist, last one wins (but duplicates are ambiguous anyway).
            _byName[n] = so;
        }

        // Re-bind any missing object refs
        foreach (var link in _links)
        {
            if (link == null) continue;
            if (link.a == null && !string.IsNullOrWhiteSpace(link.aName) && _byName.TryGetValue(link.aName, out var a))
                link.a = a;
            if (link.b == null && !string.IsNullOrWhiteSpace(link.bName) && _byName.TryGetValue(link.bName, out var b))
                link.b = b;
        }
    }

    Material GetLineMaterial()
    {
        if (lineMaterial != null) return lineMaterial;

        if (_runtimeMat != null) return _runtimeMat;

        // Try a handful of common built-in/SRP shader names.
        // If none are found, Unity will still create a material but it may render pink until a valid shader is assigned.
        Shader shader = null;
        shader = Shader.Find("Sprites/Default");
        if (shader == null) shader = Shader.Find("Unlit/Color");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (shader == null) shader = Shader.Find("HDRP/Unlit");
        if (shader == null) shader = Shader.Find("Hidden/Internal-Colored");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Hidden/InternalErrorShader");

        _runtimeMat = new Material(shader);
        _runtimeMat.name = "SafetyLineVisualizer_RuntimeMat";
        _runtimeMat.hideFlags = HideFlags.DontSaveInBuild | HideFlags.DontSaveInEditor;
        return _runtimeMat;
    }

    void RebuildLines()
    {
        ClearLines();

        var model = client != null ? client.compiledModel : null;
        if (model == null || model.rules == null) return;

        RefreshObjectMap();

        foreach (var rule in model.rules)
        {
            if (rule == null) continue;
            if (string.IsNullOrWhiteSpace(rule.A) || string.IsNullOrWhiteSpace(rule.B)) continue;

            var go = new GameObject($"SafetyLine {rule.A} ↔ {rule.B}");
            go.transform.SetParent(transform, false);

            var lr = go.AddComponent<LineRenderer>();
            lr.useWorldSpace = true;
            lr.positionCount = 2;
            lr.startWidth = lr.endWidth = Mathf.Max(0.0001f, lineWidth);
            lr.material = GetLineMaterial();
            lr.numCapVertices = 4;
            lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            lr.receiveShadows = false;

            var link = new LineLink
            {
                rule = rule,
                lr = lr,
                aName = rule.A,
                bName = rule.B,
                a = _byName.TryGetValue(rule.A, out var a) ? a : null,
                b = _byName.TryGetValue(rule.B, out var b) ? b : null,
            };

            _links.Add(link);
        }
    }

    void ClearLines()
    {
        for (int i = 0; i < _links.Count; i++)
        {
            var link = _links[i];
            if (link?.lr != null)
            {
                // Destroy the whole line GameObject
                if (Application.isPlaying)
                    Destroy(link.lr.gameObject);
                else
                    DestroyImmediate(link.lr.gameObject);
            }
        }
        _links.Clear();
    }

    void SetAllEnabled(bool enabled)
    {
        foreach (var link in _links)
        {
            if (link?.lr != null)
                link.lr.enabled = enabled;
        }
    }

    void UpdateLines()
    {
        if (!showLines)
        {
            SetAllEnabled(false);
            return;
        }

        float sat = Mathf.Max(0.0001f, violationSaturationMeters);
        float width = Mathf.Max(0.0001f, lineWidth);

        foreach (var link in _links)
        {
            if (link == null || link.lr == null) continue;

            // Keep width live-editable
            if (!Mathf.Approximately(link.lr.startWidth, width))
                link.lr.startWidth = link.lr.endWidth = width;

            if (link.a == null || link.b == null)
            {
                link.lr.enabled = false;
                continue;
            }

            Vector3 pa = link.a.transform.position;
            Vector3 pb = link.b.transform.position;
            link.lr.SetPosition(0, pa);
            link.lr.SetPosition(1, pb);

            float d = Vector3.Distance(pa, pb);
            float ra = link.a.GetRadiusMeters();
            float rb = link.b.GetRadiusMeters();
            float clearance = link.rule != null ? link.rule.clearance : 0f;
            float residual = d - (ra + rb + clearance);

            bool violating = residual < 0f;
            if (onlyShowViolatingLines && !violating)
            {
                link.lr.enabled = false;
                continue;
            }

            // Color mapping:
            // - safe (residual >= 0): solid safeColor
            // - violating (residual < 0): lerp toward dangerColor as violation depth increases
            Color c = safeColor;
            if (violating)
            {
                float severity01 = Mathf.Clamp01((-residual) / sat);
                c = Color.Lerp(safeColor, dangerColor, severity01);
            }

            link.lr.startColor = link.lr.endColor = c;
            link.lr.enabled = true;
        }
    }
}
