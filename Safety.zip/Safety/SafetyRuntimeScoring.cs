using System.Collections.Generic;
using UnityEngine;

public static class SafetyRuntimeScoring
{
    public struct RuleRuntimeInfo
    {
        public RuleDto rule;        // A, B, clearance, weight
        public float distance;      // meters (Unity units)
        public float residual;      // d - (rA+rB+clearance).  <0 means too close
        public float risk0To1;      // 0 safe .. 1 dangerous
        public float weightedRisk;  // weight * risk
    }

    public struct SafetyEval
    {
        public float compositeRisk0To1;
        public float safety0To5;
        public List<RuleRuntimeInfo> perRule;
    }

    static float SigmoidStable(float x)
    {
        x = Mathf.Clamp(x, -60f, 60f);
        return 1f / (1f + Mathf.Exp(-x));
    }

    public static SafetyEval Evaluate(
        Dictionary<string, (Vector3 pos, float r)> byName,
        List<RuleDto> rules,
        float alphaGain,
        float scaleRes
    )
    {
        var per = new List<RuleRuntimeInfo>(rules != null ? rules.Count : 0);

        float sum = 0f, wsum = 0f;
        if (rules == null || byName == null)
        {
            return new SafetyEval { compositeRisk0To1 = 0f, safety0To5 = 5f, perRule = per };
        }

        float sr = Mathf.Max(scaleRes, 1e-6f);

        foreach (var rule in rules)
        {
            if (rule == null) continue;
            if (!byName.TryGetValue(rule.A, out var A)) continue;
            if (!byName.TryGetValue(rule.B, out var B)) continue;

            float d = Vector3.Distance(A.pos, B.pos);
            float res = d - (A.r + B.r + rule.clearance);

            // risk goes to 1 when residual is very negative (too close),
            // risk goes to 0 when residual is positive (enough clearance)
            float risk = SigmoidStable(-(res) / sr * alphaGain);
            float wr = rule.weight * risk;

            per.Add(new RuleRuntimeInfo {
                rule = rule,
                distance = d,
                residual = res,
                risk0To1 = risk,
                weightedRisk = wr,
            });

            sum += wr;
            wsum += rule.weight;
        }

        float compositeRisk = (wsum > 0f) ? (sum / wsum) : 0f;
        float safety = Mathf.Clamp(5f - 5f * compositeRisk, 0f, 5f);

        return new SafetyEval {
            compositeRisk0To1 = compositeRisk,
            safety0To5 = safety,
            perRule = per
        };
    }

    // Backward-compatible wrapper
    public static float ComputeSafety0To5(
        Dictionary<string, (Vector3 pos, float r)> byName,
        List<RuleDto> rules,
        float alphaGain,
        float scaleRes
    )
    {
        return Evaluate(byName, rules, alphaGain, scaleRes).safety0To5;
    }
}
